export const API_URL = 'http://127.0.0.1:8000'; //this is to test you development backend
//export const API_URL = 'https://yourbackend.onrender.com'; //this is to test your live deployed backend